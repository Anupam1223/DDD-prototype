package com.fyp.renthouse.renting;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RentingApplication {

	public static void main(String[] args) {
		SpringApplication.run(RentingApplication.class, args);
	}

}
