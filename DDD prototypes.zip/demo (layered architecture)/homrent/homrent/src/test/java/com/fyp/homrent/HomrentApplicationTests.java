package com.fyp.homrent;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HomrentApplicationTests {

	@Test
	void contextLoads() {
	}

}
