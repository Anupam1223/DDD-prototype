package com.fyp.homrent;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HomrentApplication {

	public static void main(String[] args) {
		SpringApplication.run(HomrentApplication.class, args);
	}

}
