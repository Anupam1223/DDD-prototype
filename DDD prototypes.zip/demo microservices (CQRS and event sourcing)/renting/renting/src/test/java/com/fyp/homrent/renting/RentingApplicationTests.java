package com.fyp.homrent.renting;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RentingApplicationTests {

	@Test
	void contextLoads() {
	}

}
