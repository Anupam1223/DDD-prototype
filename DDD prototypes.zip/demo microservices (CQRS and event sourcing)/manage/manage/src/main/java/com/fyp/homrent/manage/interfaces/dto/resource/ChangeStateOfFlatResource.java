package com.fyp.homrent.manage.interfaces.dto.resource;

import lombok.Data;

@Data
public class ChangeStateOfFlatResource {

    private String flatId;

}
