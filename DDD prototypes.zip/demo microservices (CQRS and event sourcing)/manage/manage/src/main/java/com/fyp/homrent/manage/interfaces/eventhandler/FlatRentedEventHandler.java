// package com.fyp.homrent.manage.interfaces.eventhandler;

// import com.fyp.homrent.shareddomain.FlatRentedEvent;

// import org.axonframework.eventhandling.EventHandler;
// import org.springframework.stereotype.Service;

// import lombok.extern.slf4j.Slf4j;

// @Service
// @Slf4j
// public class FlatRentedEventHandler {

// @EventHandler
// public void on(FlatRentedEvent flatRentedEvent) {

// log.info("flatId {}", flatRentedEvent.getFlatID());
// }
// }
